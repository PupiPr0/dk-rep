const IP_API     = 'https://api.dkon.app/.Config/GetMyIP';
const TIME_API   = 'https://api.dkon.app/.Config/TimeZone';
const LANG_CFG   = 'https://res.dkon.app/ext/myip/lang/config.json';
const LANG_BASE  = 'https://res.dkon.app/ext/myip/lang/';
const LANG_LIST  = 'https://res.dkon.app/ext/myip/lang/languages.json';

const FALLBACK_EN = {
  titleLocation: "You are in:",
  country: "Country:",
  realIp: "Real IP:",
  proxyIp: "Proxy IP:",
  localTime: "Local time:",
  refresh: "Refresh",
  loading: "Loading...",
  error: "Error"
};

let translations = { ...FALLBACK_EN };
let countries = {};

async function initLocalization() {
  try {
    const [cfgResp, langListResp] = await Promise.all([
      fetch(LANG_CFG + '?t=' + Date.now()),
      fetch(LANG_LIST + '?t=' + Date.now())
    ]);

    if (!cfgResp.ok) throw new Error('no config');
    const config = await cfgResp.json();
    const langList = await langListResp.json();

    let lang = config.current || langList.default || 'en';
    if (config.current === 'auto' && langList.available.includes(chrome.i18n.getUILanguage())) {
      lang = chrome.i18n.getUILanguage().toLowerCase().split('-')[0];
    }
    lang = lang.toLowerCase();

    console.log('Выбран язык:', lang);

    const [langResp, countryResp] = await Promise.all([
      fetch(LANG_BASE + lang + '.json?t=' + Date.now()),
      fetch(LANG_BASE + 'countries.json?t=' + Date.now())
    ]);

    if (langResp.ok) {
      const json = await langResp.json();
      translations = { ...FALLBACK_EN, ...json };
      console.log('Переводы загружены:', lang);
    }

    if (countryResp.ok) {
      countries = await countryResp.json();
      console.log('Страны загружены');
    }

  } catch (e) {
    console.log('Локализация с сервера недоступна — используем английский:', e);
  }
}

async function getData() {
  await initLocalization();

  try {
    const [ipResp, timeResp] = await Promise.all([
      fetch(IP_API, { cache: "no-store" }),
      fetch(TIME_API, { cache: "no-store" })
    ]);

    const ip = await ipResp.json();
    const zones = await timeResp.json();
    const realZone = zones.find(z => !z.timezone.includes('UTC'));

    let code = 'xx';
    if (ip.DkonCountry) {
      try { code = atob(ip.DkonCountry).trim().toLowerCase(); }
      catch { code = ip.Country?.toLowerCase() || 'xx'; }
    } else {
      code = ip.Country?.toLowerCase() || 'xx';
    }

    return {
      code,
      countryName: countries[code] || code.toUpperCase(),
      realIp: ip.RealIP || '—',
      proxyIp: ip.ProxyIP || '—',
      localTime: realZone?.current_time.split(' ')[1].slice(0,5) || '—',
      translations
    };
  } catch {
    return { error: true, translations };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'getData') {
    getData().then(sendResponse);
    return true;
  }
});