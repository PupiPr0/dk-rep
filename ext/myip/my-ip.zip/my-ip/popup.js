// popup.js — только отображение

let t = key => key;
let data = {};

async function load() {
  document.getElementById('loading').classList.remove('hidden');
  document.getElementById('content').classList.add('hidden');
  document.getElementById('error').classList.add('hidden');

  const response = await chrome.runtime.sendMessage({ action: 'getData' });
  
  if (response.error) {
    document.getElementById('error').classList.remove('hidden');
    document.getElementById('loading').classList.add('hidden');
    return;
  }

  data = response;
  t = key => response.translations[key] || key;

  applyTranslations();

  document.getElementById('flagImg').src = `https://res.dkon.app/flags/${data.code}.svg`;
  document.getElementById('countryName').textContent = data.countryName;
  document.getElementById('realIp').textContent = data.realIp;
  //document.getElementById('proxyIp').textContent = data.proxyIp;
  document.getElementById('localTime').textContent = data.localTime;

  document.getElementById('loading').classList.add('hidden');
  document.getElementById('content').classList.remove('hidden');
}

function applyTranslations() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    el.textContent = t(key);
  });
}

document.addEventListener('DOMContentLoaded', load);
document.getElementById('refresh').addEventListener('click', load);